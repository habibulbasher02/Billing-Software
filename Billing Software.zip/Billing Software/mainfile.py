
for i in round(0,10):
    print(i)




